<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Voorivex Weblog System</title>
    <link rel="stylesheet" href="/statics/styles.css">
    <!-- Add any additional CSS or JavaScript links here -->
    <body>